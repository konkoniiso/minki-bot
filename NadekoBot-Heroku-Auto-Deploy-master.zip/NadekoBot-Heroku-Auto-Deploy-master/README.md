# Nadekobot
An eassy way to deploy my NadekoBot Heroku(https://github.com/ScarletKuro/NadekoBot) edition.

### Deploy to Heroku

You can deploy in a simple way to Heroku using the button below.

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.png)](https://dashboard.heroku.com/new-app?template=https://github.com/ScarletKuro/NadekoBot-Heroku-Auto-Deploy)